# RotorDynamicsTrial-Part3
The project deals with rotor dynamics simulation using MATLAB.
 Tuturial purposes only.
Everything starts from MAIN.m file. 
Part 3 deals with dynamic properties of a fluid-film bearing

function [dydt,F1,F2]=equationsOfMotion2(t,y,dyn,X1E,X2E,F1E,F2E,K,B)
%Equations of motion for the case 1

%Initialisation
mass=dyn.mass;
deltam=dyn.deltam;
Fext=dyn.Fext;
g=dyn.g;
n_rps=dyn.n_rps;


omega=2*pi*n_rps;
dydt=zeros(4,1);%the right-side parts of the equations

%Fluid film reaction forces are linearised by K and B
%!!!!!!!!!!!Enter your code here!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
K=K
B=B
F1=F1E-K(1,1)*(y(2)-X1E)-K(1,2)*(y(4)-X2E)-B(1,1)*y(1)-B(1,2)*y(3)
F2=F2E-K(2,1)*(y(2)-X1E)-K(2,2)*(y(4)-X2E)-B(2,1)*y(1)-B(2,2)*y(3)
%[F1,F2]=[F1E,F2E]-(K*[y(2)-X1E;y(4)-X2E])-(B*[y(1);y(3)]);
%!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

%The right-side parts of the equations
%!!!!!!!!!!!Enter your code here!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
dydt(1)=(2*F1+deltam*(omega)^2*sin(omega*t)+Fext(1))/mass;
dydt(2)=y(1);
dydt(3)=(2*F2+deltam*(omega)^2*cos(omega*t)+Fext(2)+mass*g)/mass;
dydt(4)=y(3);
%!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 t%print time
end